
package datastructures;


public class SelectedBusiness {
    String name;
    int index;
    
    public void setSelectedBusiness(String name){
        this.name  = name;
    }
    public String getSelectedBusiness(){
        return name;
    }
    public void setindex(int index){
        this.index = index;
    }
    public int getIndex(){
        return index;
    }
}
