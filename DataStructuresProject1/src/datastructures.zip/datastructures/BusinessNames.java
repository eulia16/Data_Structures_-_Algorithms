
package datastructures;


public class BusinessNames {
    private String busID;
    private String busName;
    
    public String getBusID(){
        return busID;
    }
    
    public String getbusName(){
        return busName;
    }
    public void setBusID(String is){
        busID = is;
    }
    public void setBusName(String is){
        busName = is;
    }
    
    
}
